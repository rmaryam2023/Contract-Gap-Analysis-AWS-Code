const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    console.log('GetDashboardData invoked');
    
    try {
        // Scan DynamoDB table for all compliance metrics
        const command = new ScanCommand({
            TableName: 'complianceMetrics'
        });
        
        const response = await docClient.send(command);
        const items = response.Items || [];
        
        console.log(`Found ${items.length} compliance records`);
        
        if (items.length === 0) {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    totalMSAs: 0,
                    overallComplianceRate: 0,
                    highRiskIssues: 0,
                    fullyCompliant: 0,
                    byJurisdiction: [],
                    topIssues: [],
                    recentAnalyses: []
                })
            };
        }
        
        // Calculate aggregated metrics
        const totalMSAs = items.length;
        let totalComplianceRate = 0;
        let totalHighRiskIssues = 0;
        let fullyCompliant = 0;
        
        // Track jurisdiction stats
        const jurisdictionMap = {};
        
        // Track issue types and their frequency
        const issueTypeCounter = {};
        
        // Recent analyses
        const recentAnalyses = [];
        
        items.forEach(item => {
            // Overall stats
            const complianceRate = parseFloat(item.compliance_rate) || 0;
            totalComplianceRate += complianceRate;
            
            const highRisk = parseInt(item.high_risk_issues) || 0;
            totalHighRiskIssues += highRisk;
            
            if (complianceRate >= 100) {
                fullyCompliant++;
            }
            
            // Jurisdiction aggregation
            const jurisdiction = (item.jurisdiction || 'UNKNOWN').toUpperCase();
            if (!jurisdictionMap[jurisdiction]) {
                jurisdictionMap[jurisdiction] = {
                    count: 0,
                    totalRate: 0
                };
            }
            jurisdictionMap[jurisdiction].count++;
            jurisdictionMap[jurisdiction].totalRate += complianceRate;
            
            // Track issue types from detailed findings
            if (item.issue_types && Array.isArray(item.issue_types)) {
                item.issue_types.forEach(issueType => {
                    if (!issueTypeCounter[issueType]) {
                        issueTypeCounter[issueType] = 0;
                    }
                    issueTypeCounter[issueType]++;
                });
            }
            
            // Recent analyses
            recentAnalyses.push({
                msa_name: item.msa_id || 'Unknown',
                jurisdiction: jurisdiction,
                compliance_rate: complianceRate,
                timestamp: item.analysis_timestamp || new Date().toISOString(),
                overall_status: item.overall_status || 'UNKNOWN'
            });
        });
        
        // Calculate averages
        const overallComplianceRate = totalMSAs > 0 ? totalComplianceRate / totalMSAs : 0;
        
        // Format jurisdiction data
        const byJurisdiction = Object.entries(jurisdictionMap).map(([jurisdiction, data]) => ({
            jurisdiction: jurisdiction,
            count: data.count,
            compliance_rate: data.count > 0 ? data.totalRate / data.count : 0
        })).sort((a, b) => b.compliance_rate - a.compliance_rate);
        
        // Format top issues
        const topIssues = Object.entries(issueTypeCounter)
            .map(([issueType, count]) => ({
                issue_type: issueType,
                count: count
            }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 10); // Top 10 issues
        
        // Sort recent analyses by timestamp
        recentAnalyses.sort((a, b) => 
            new Date(b.timestamp) - new Date(a.timestamp)
        );
        
        const dashboardData = {
            totalMSAs: totalMSAs,
            overallComplianceRate: Math.round(overallComplianceRate * 100) / 100,
            highRiskIssues: totalHighRiskIssues,
            fullyCompliant: fullyCompliant,
            byJurisdiction: byJurisdiction,
            topIssues: topIssues,
            recentAnalyses: recentAnalyses.slice(0, 20) // Last 20
        };
        
        console.log('Dashboard data prepared:', JSON.stringify(dashboardData, null, 2));
        
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(dashboardData)
        };
        
    } catch (error) {
        console.error('Error getting dashboard data:', error);
        
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Failed to fetch dashboard data',
                message: error.message
            })
        };
    }
};